#include <iostream>
using namespace std;
int main(int argc, char** argv)
{
	cout << output;	
	return 0;
}
