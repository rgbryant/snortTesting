#ifndef __RZB_SMTP_DUMP_H__
#define __RZB_SMTP_DUMP_H__

#include "sf_snort_packet.h"

int smtpdumpereval(SFSnortPacket *);

#endif // __RZB_SMTP_DUMP_H__

